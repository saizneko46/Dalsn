module.exports = {
  BOT_TOKEN: "7852148401:AAFdd4GVhpfpUpOqzWnxT-dbcuybvpLgny8",
    allowedDevelopers: ['6810074747'], // ID
};